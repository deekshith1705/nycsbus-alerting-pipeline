import json
import boto3
import re
import os
from datetime import datetime
from aws_embedded_metrics import metric_scope

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

S3_BUCKET = os.environ['S3_BUCKET']              # e.g., nycsbus-breakdowns-21c7be88
DYNAMO_TABLE = os.environ['DYNAMO_TABLE']        # e.g., bus-breakdowns1

REQUIRED_FIELDS = ['Busbreakdown_ID', 'Route_Number', 'Reason']

@metric_scope
def emit_high_priority_metric(metrics, event):
    metrics.set_namespace("NYCSBus/Alerts")
    metrics.put_metric("HighPriorityAlerts", 1, "Count")
    metrics.set_dimensions({
        "Route": event["Route_Number"],
        "Reason": event["Reason"]
    })

def lambda_handler(event, context):
    # Handle direct invocation or API Gateway format
    if 'body' in event:
        event = json.loads(event['body'])

    missing_fields = [f for f in REQUIRED_FIELDS if f not in event]
    if missing_fields:
        return {
            "statusCode": 400,
            "body": f"Missing required fields: {', '.join(missing_fields)}"
        }

    # Add alert_priority
    event['alert_priority'] = get_alert_priority(event['Reason'])

    # Add average_delay_minutes
    event['average_delay_minutes'] = parse_delay(event.get('How_Long_Delayed', ''))

    # Write raw JSON to S3
    s3.put_object(
        Bucket=S3_BUCKET,
        Key=f"raw/{event['Busbreakdown_ID']}.json",
        Body=json.dumps(event)
    )

    # Write to DynamoDB
    table = dynamodb.Table(DYNAMO_TABLE)
    table.put_item(Item={
        **event,
        "Occurred_On": event.get("Occurred_On", datetime.utcnow().isoformat())
    })

    # Emit custom CloudWatch metric if high-priority
    if event['alert_priority'] == 'high':
        emit_high_priority_metric(event)

    # Log structured JSON
    print(json.dumps({
        "Busbreakdown_ID": event["Busbreakdown_ID"],
        "Route_Number": event["Route_Number"],
        "Status": "Processed"
    }))

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Event processed successfully"})
    }

def get_alert_priority(reason):
    reason = reason.lower()
    if reason in ["mechanical problem", "flat tire", "won't start", "accident"]:
        return "high"
    elif reason in ["heavy traffic", "weather conditions"]:
        return "medium"
    elif reason in ["delayed by school", "other", "problem run"]:
        return "low"
    else:
        return "low"

def parse_delay(delay_str):
    delay_str = delay_str.lower().strip()

    if "hour" in delay_str:
        match = re.search(r'(\d+)', delay_str)
        return int(match.group(1)) * 60 if match else 0
    elif "-" in delay_str:
        nums = re.findall(r'\d+', delay_str)
        if len(nums) == 2:
            return (int(nums[0]) + int(nums[1])) // 2
    else:
        match = re.search(r'(\d+)', delay_str)
        if match:
            return int(match.group(1))
    return 0
